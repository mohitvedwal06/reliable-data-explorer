# Order Explorer — React + TypeScript

A demo data explorer with 12,000 generated orders and a deliberately unreliable mock API.

## Requirements

- Node.js 20+
- npm

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:5173. Vite proxies `/api` to `http://localhost:3001`.

## Features

- Server-side search, status/city filters, sorting, and pagination.
- URL-backed view state (`q`, `status`, `city`, `sort`, `order`, `page`, `pageSize`).
- Debounced search and abortable fetches. TanStack Query keys results by the complete query state; an older request cannot replace the current query's result.
- API adds 200–3000 ms latency and simulates a 10% 503 failure rate.
- Virtualized visible table rows with TanStack Virtual.
- Distinct initial loading, empty, error, retry, and updating states. Errors do not display cached old results as if they were current.
- Keyboard-operable filters, sortable column buttons, pagination, visible focus rings, and screen-reader status announcements.
- Deep-linked detail route (`/orders/ORD-000001?q=...`) retains list query parameters and restores scroll position on return.

## API

- `GET /api/health`
- `GET /api/orders?q=&status=&city=&sort=&order=&page=&pageSize=`
- `GET /api/orders/:id`

Allowed sort fields: `id`, `customer`, `status`, `total`, `createdAt`, `city`. Page size is clamped to 10–100.

## Important implementation notes

- Search text is debounced by 350 ms; filters and sorting update the URL immediately.
- `AbortSignal` from TanStack Query is passed to `fetch`, so superseded requests can be cancelled when the browser/request lifecycle permits. Query keys ensure each response belongs to its own state.
- The mock API uses in-memory generated data so it starts without a database. Search/filter/sort run on the server API process, not in the browser.
- The 10% failure behavior is intentionally disruptive for testing. A Retry button reissues the request.
- `sessionStorage` is used only for the list scroll offset during a detail round trip; all view-defining state is in the URL.

## Production hardening ideas

For a real backend, add database indexes (for status, created date, and searchable fields), use cursor pagination for frequently changing datasets, validate query parameters with a schema, and add request IDs/structured logs. If implementing partial multi-source results, model each source's status separately and label partial results explicitly; this single-source demo fails the whole request rather than pretending it returned partial data.